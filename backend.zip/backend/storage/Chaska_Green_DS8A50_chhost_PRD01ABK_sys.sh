chhost -dev IBM.2107-78NRC91 -action map -volume 1800-180F PRD01ABK_sys_01
chhost -dev IBM.2107-78NRC91 -action map -volume 1810-181F PRD01ABK_sys_02
chhost -dev IBM.2107-78NRC91 -action map -volume 1900-190F PRD01ABK_sys_01
chhost -dev IBM.2107-78NRC91 -action map -volume 1910-191F PRD01ABK_sys_02
