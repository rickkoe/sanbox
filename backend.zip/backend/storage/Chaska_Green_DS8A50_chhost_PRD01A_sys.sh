chhost -dev IBM.2107-78NRC91 -action map -volume 1000-1038 PRD01A_sys_01
chhost -dev IBM.2107-78NRC91 -action map -volume 1039-1070 PRD01A_sys_02
chhost -dev IBM.2107-78NRC91 -action map -volume 1100-1137 PRD01A_sys_01
chhost -dev IBM.2107-78NRC91 -action map -volume 1138-1170 PRD01A_sys_02
